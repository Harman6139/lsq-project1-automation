Boyle LSQ Workspace
Generated: 2026-06-12 14:56:26

Project_1_May2026_Update contains the current monthly Project 1 update.
Assignment_2 contains the leveraged S&P 500 analysis.

For the viewer-ready version, open the PDF files in Google Drive.
For LaTeX source, open the .tex file inside the relevant project folder.
